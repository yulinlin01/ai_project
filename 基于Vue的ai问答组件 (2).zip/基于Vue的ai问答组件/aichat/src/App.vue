<template>
  <div class="container">
    <!-- 头部 -->
    <div class="header">  
            <h1>AI助手测试</h1>
    </div>

    <!-- 对话区域 -->
    <div class="chat-messages" ref="chatContainer">
      <!-- 消息列表 -->
      <div ref="messagesWrapper">
        <template v-for="(message, index) in messages" :key="index">
          <!-- 用户消息 -->
          <div class="user-message" v-if="message.type === 'user'">
                {{ message.content }}
          </div>
          <!-- AI消息 -->
          <div v-else>
          <div class="message-content">
                {{ message.content }}    
             </div>
          </div>
        </template>
      </div>
    </div>

    <!-- 输入区域 -->
    <div class="input-area">
      <div class="input-container">
        <textarea 
          v-model="userInput" 
          @keyup.enter="sendMessage"
          placeholder="输入问题..." 
        ></textarea>
        <button 
          @click="sendMessage" 
          :disabled="!userInput.trim()"
          class="send-button"
        >提交
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
// 引入Vue相关功能
import { ref, onMounted, nextTick } from 'vue'
//用于滚动到聊天底部
const chatContainer = ref(null)
// 输入内容
const userInput = ref('')
// 消息列表
const messages = ref([
  { type: 'assistant', content: '你好！我是您的专属AI助手，有什么可以帮助你的吗？' }
])
// 引入API请求地址，使用的是豆包大模型，
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions' 
// 发送信息到ai并获取回复
const sendMessage = async () => {
  // 检查输入是否为空
  if (!userInput.value.trim()) return
  // 添加用户消息
  const userMessage = {
    type: 'user',
    content: userInput.value,
  }
  messages.value.push(userMessage)
  // 滚动到底部
  scrollToBottom()
  
  // 清空输入框
  userInput.value = ''
  // 使用try-catch处理API调用
  try {
    //记录消息数量，用于移除‘思考中...’消息
    const thinking = messages.value.length
    // 添加‘思考中’提醒
    messages.value.push({ 
      type: 'assistant', 
      content: '思考中...',
    })
    scrollToBottom()
    // 调用AI API
    const response = await fetch(API_URL, {
      method: 'POST',
      // 设置请求头
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer cd90ae03-ce96-4cc3-a982-166765717bd1' // 我的豆包api-key
      },
      // 设置请求体
      // 使用了doubao-1-5-lite-32k-250115模型
      body: JSON.stringify({
        model: 'doubao-1-5-lite-32k-250115', 
        // 将用户和AI消息转换为API所需格式
        messages: messages.value.map(msg => ({
          role: msg.type === 'user' ? 'user' : 'assistant',
          content: msg.content
        })),
        // 控制生成内容的随机性
        temperature: 0.7
      })
    })
    
    // 移除思考中消息
    messages.value.splice(thinking, 1)
    // 检查API响应状态
    if (!response.ok) {
      throw new Error(`API请求失败: ${response.status}`)
    }
    // 处理API响应
    const data = await response.json()
    // 提取，添加AI回复
    const aiResponse = data.choices[0].message.content
    messages.value.push({ 
      type: 'assistant', 
      content: aiResponse,
        })
  } catch (error) {
    console.error('API调用错误:', error)
    // 显示错误消息
    messages.value.push({ 
      type: 'assistant', 
      content: '抱歉，发生错误无法获取回复。请稍后再试。',
    })
  } finally {
    // 确保滚动到底部
    scrollToBottom()
  }
}
// 滚动到聊天底部的函数
const scrollToBottom = () => {
  // 使用nextTick确保DOM更新后执行滚动
  nextTick(() => {
    if (chatContainer.value) {
  // 将滚动位置设置为容器高度，确保最新消息可见      
      chatContainer.value.scrollTop = chatContainer.value.scrollHeight
    }
  })
}
// 在组件挂载时滚动到底部
onMounted(() => {
  scrollToBottom()
})
</script>

<style scoped>
.container {
  max-width: 800px;
  margin: 0 auto;
  border-radius: 16px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  height: 90vh;
  max-height: 800px;
  min-height: 600px;
  border: 1px solid #f0f0f0;
}

.header {
  background: linear-gradient(90deg, #ee6199, #8b5cf6);
  color: rgb(255, 255, 255);
  padding: 15px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.chat-messages {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  background: linear-gradient(90deg, #f9e1f8, #efd6f8);
}

.user-message {
  display: flex;
  justify-content: flex-end;
  gap: 16px;
  align-items: flex-start;
}

.message-content {
  max-width: 80%;
}

.input-area {
  padding: 16px 24px;
  border-top: 1px solid #e5e7eb;
  background: linear-gradient(90deg, #f04aab, #8b5cf6);
}

.input-container {
  position: relative;
}

.input-area textarea {
  width: 100%;
  padding: 12px 0px 12px 6px;
  border-radius: 12px;
  border: 1px solid #d1d5db;
  outline: none;
  resize: none;
  min-height: 48px;
  font-family: inherit;
  font-size: 14px;
  background: linear-gradient(90deg, #f8daeb, #d7cbf5);
}

.send-button {
  position: absolute;
  right: 12px;
  bottom: 12px;
  width: 52px;
  height: 32px;
  border-radius: 20%;
  background: #8957ff;
  color: rgb(129, 128, 128);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border: none;
  transition: all 0.5s ease;
}

.send-button:disabled {
  background: #f6f6f6;
  cursor: not-allowed;
}

.send-button:not(:disabled):hover {
  color: black;
  background: #7c3aed;
  transform: scale(1.35);
}

.send-button:not(:disabled):active {
  transform: scale(0.95);
}
</style> 